# CS50x-Scratch-Racing-Game
Jogo de corrida desenvolvido como projeto pratico para o curso CS50x da Harvard University, utilizando lógica de programação em blocos e conceitos de abatração
